export class Payment {
    id: number;
    amount: number;
    created_on: string;
    paid_by: any;
    charge: any;
  }