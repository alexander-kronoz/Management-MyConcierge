import { Component } from "@angular/core";

@Component({
    selector: 'payments-container',
    templateUrl: './payments.component.html',
    styleUrls: ['./payments.component.scss']
})

export class PaymentsComponent {

    constructor() { }
}