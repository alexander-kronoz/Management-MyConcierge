import { Component } from "@angular/core";

@Component({
    selector: 'payment-method-list',
    templateUrl: './payment-method-list.component.html',
    styleUrls: ['./payment-method-list.component.scss']
})

export class PaymentMethodListComponent {

    constructor() { }

}