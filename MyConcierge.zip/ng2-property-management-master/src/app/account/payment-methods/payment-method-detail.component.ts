import { Component } from "@angular/core";

@Component({
    selector: 'payment-method-detail',
    templateUrl: './payment-method-detail.component.html',
    styleUrls: ['./payment-method-detail.component.scss']
})

export class PaymentMethodDetailComponent {

    constructor() { }

}