import { Component } from "@angular/core";

@Component({
    selector: 'account-detail',
    templateUrl: './account-detail.component.html',
    styles: ['./account-detail.component.scss']
})

export class AccountDetailComponent {

    constructor() { }

}