import { Component } from "@angular/core";

@Component({
    selector: 'signature',
    templateUrl: './signature.component.html',
    styles: ['./signature.component.scss']
})

export class SignatureComponent {

    constructor() { }

}