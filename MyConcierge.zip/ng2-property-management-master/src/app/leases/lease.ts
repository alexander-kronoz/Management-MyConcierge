export class Lease {
    amount: number;
    created_on: string;
    date_due: string;
    description: string;
    lease: any;
    name: string;
    url: string;
  }