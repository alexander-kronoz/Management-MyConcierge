import { Component } from "@angular/core";

@Component({
    selector: 'property-container',
    templateUrl: './property.component.html',
    styleUrls: ['./property.component.scss']
})

export class PropertyComponent {

    constructor() { }

}