import { Component } from "@angular/core";

@Component({
    selector: 'help-container',
    templateUrl: './help.component.html',
    styleUrls: ['./help.component.scss']
})

export class HelpComponent {

    constructor() { }

}