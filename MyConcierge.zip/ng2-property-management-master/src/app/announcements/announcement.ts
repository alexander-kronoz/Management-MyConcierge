export class Announcement {
    name: string;    
    created_on: string;
    description: string;
    url: string;
  }