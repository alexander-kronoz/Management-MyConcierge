import { Component } from "@angular/core";

@Component({
    selector: 'documents-container',
    templateUrl: './documents.component.html',
    styleUrls: ['./documents.component.scss']
})

export class DocumentsComponent {

    constructor() { }

}