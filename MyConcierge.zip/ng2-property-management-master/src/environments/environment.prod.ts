export const environment = {
  production: true,
  envName: 'prod',
  baseUrl: 'http://gmc.aaronchesley.com/api',
};
